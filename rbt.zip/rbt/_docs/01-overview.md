# Overview

mkdir rbt
cd rbt
python -m venv .venv

.\.venv\Scripts\Activate.ps1

python -m pip install --upgrade pip
pip install pika

pip install -r requirements.txt